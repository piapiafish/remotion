# Third-party asset notices

The project modifies third-party 3D models for browser rendering. The
original creators and licenses are listed below. Product names and trademarks
belong to their respective owners; those companies do not sponsor or endorse
this project.

## Iphone 17 pro

- Creator: [Ibrahim.Bhl](https://sketchfab.com/Ibrahim.Bhl)
- Source: [Sketchfab model](https://sketchfab.com/3d-models/iphone-17-pro-4aeeeb41f9d14f96bb3f2589edc3edac)
- License: [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/)
- Changes: converted and prepared for browser rendering; screen material and
  transform metadata are supplied by this project.

## Phone 17 Pro Max

- Creator: [Ranguel](https://sketchfab.com/Ranguel)
- Source: [Sketchfab model](https://sketchfab.com/3d-models/phone-17-pro-max-66809964eff043a39d553c3795995008)
- License: [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/)
- Changes: optimized with glTF-Transform for browser delivery; corrective
  transforms, colorways, and screen integration are supplied by this project.

The source describes this model as an unofficial, fan-made visualization.

## Google Pixel 9 Pro XL

- Creator: [Fiq KM](https://www.blendkit.com/?query=author_id:182766)
- Source: [Blendkit model](https://www.blendkit.com/asset-gallery-detail/511e7e71-de38-4d6e-99da-9b34cc4dd738/)
- License: [Blendkit Royalty Free](https://www.blendkit.com/docs/licenses/)
- Changes: exported to GLB and optimized for browser delivery; corrective
  transforms, colorways, and screen integration are supplied by this project.

In addition to the Blendkit license, the project maintainer obtained the
creator's permission to redistribute the optimized runtime GLB included in
this repository. The original source file is not distributed.

## Samsung S26 Ultra

- Creator: [Sagar Modi](https://sketchfab.com/modis1761)
- Source: [Sketchfab model](https://sketchfab.com/3d-models/samsung-s26-ultra-7ff228963ea446f39f46a5541f71e352)
- License: [Creative Commons Attribution 4.0 International](https://creativecommons.org/licenses/by/4.0/)
- Changes: optimized with glTF-Transform for browser delivery; corrective
  transforms and screen integration are supplied by this project.
# P0 offline rendering additions (2026-10-29)

The original notices below are retained. The following additional runtime resources are bundled so model loading and lighting do not require a CDN:

- `public/draco/`: the unchanged glTF Draco decoder from `three@0.185.1`, Draco under Apache-2.0 (`public/draco/DRACO-LICENSE.txt`); the Three.js MIT notice is retained in `public/draco/THREE-LICENSE.txt`. Source: https://github.com/google/draco .
- `public/environments/`: the four original drei HDRI preset assets, from Poly Haven under CC0. Asset pages, exact pinned download URLs and checksums are recorded in that directory. Primary license: https://polyhaven.com/license .

No original phone GLB, recording, reference video, license or attribution file was removed.

